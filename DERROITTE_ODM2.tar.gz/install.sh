#!/bin/sh

echo Installing OpenCV.
pip install opencv-python
pip install opencv-contrib-python
echo Installing skit-learn
pip install scikit-learn

