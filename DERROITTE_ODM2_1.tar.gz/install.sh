#!/bin/sh

echo Installing OpenCV.
pip3 install opencv-python
pip3 install opencv-contrib-python
